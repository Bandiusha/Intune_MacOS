#!/bin/bash
# VER 2.0.0 - Static Version (UI handled by Master)

# 1. User Defined variables
weburl="https://dl.google.com/chrome/mac/universal/stable/gcem/GoogleChrome.pkg"
appname="Google Chrome"
app="Google Chrome.app"
logandmetadir="/Library/Logs/Microsoft/IntuneScripts/GoogleChrome"
processpath="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
terminateprocess="true"
autoUpdate="true"

# 2. Generated variables
tempdir=$(mktemp -d)
log="$logandmetadir/$appname.log"
metafile="$logandmetadir/$appname.meta"

# 3. Supporting Functions
function startLog() {
    mkdir -p "$logandmetadir"
    exec &> >(tee -a "$log")
}

function waitForProcess() {
    processName=$1
    echo "$(date) | Checking if [$processName] is running..."
    while ps aux | grep "$processName" | grep -v grep &>/dev/null; do
        if [[ $3 == "true" ]]; then
            echo "$(date) | Terminating $processName..."
            pkill -f "$processName"
            return
        fi
        sleep 10
    done
}

function waitForDesktop() {
    until ps aux | grep /System/Library/CoreServices/Dock.app/Contents/MacOS/Dock | grep -v grep &>/dev/null; do
        sleep 5
    done
}

function updateCheck() {
    if [ -d "/Applications/$app" ]; then
        if [[ $autoUpdate == "true" ]]; then
            echo "$(date) | $appname already installed, exiting."
            exit 0
        fi
    fi
}

function downloadApp() {
    echo "$(date) | Starting download of $appname..."
    cd "$tempdir"
    curl -f -s --connect-timeout 30 --retry 5 --retry-delay 60 -L -o "chrome.pkg" "$weburl"
    if [ $? == 0 ]; then
        tempfile="$tempdir/chrome.pkg"
        echo "$(date) | Download complete: $tempfile"
    else
        echo "$(date) | ERROR: Download failed"
        exit 1
    fi
}

function installPKG() {
    waitForProcess "$processpath" "300" "$terminateprocess"
    echo "$(date) | Installing $appname..."
    
    # Clean up previous failed attempts if they exist
    if [[ -d "/Applications/$app" ]]; then
        rm -rf "/Applications/$app"
    fi

    attempt=1
    while [ $attempt -le 5 ]; do
        installer -pkg "$tempfile" -target /
        if [ "$?" = "0" ]; then
            echo "$(date) | $appname installed successfully."
            rm -rf "$tempdir"
            exit 0
        else
            echo "$(date) | Installation failed, retry $attempt of 5..."
            attempt=$((attempt + 1))
            sleep 5
        fi
    done
    echo "$(date) | ERROR: Installation failed after 5 attempts."
    exit 1
}

# --- Main Body ---
startLog
updateCheck
waitForDesktop

downloadApp
installPKG