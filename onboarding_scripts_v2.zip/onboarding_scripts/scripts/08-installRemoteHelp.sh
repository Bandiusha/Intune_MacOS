#!/bin/bash
# VER 2.0.0 - Static Version (UI handled by Master)

# 1. User Defined variables
weburl="https://aka.ms/downloadremotehelpmacos"
appname="Microsoft Remote Help"
app="Microsoft Remote Help.app"
logandmetadir="/Library/Logs/Microsoft/IntuneScripts/installRemoteHelp"
processpath="/Applications/Microsoft Remote Help.app/Contents/MacOS/Microsoft Remote Help"
terminateprocess="true"
autoUpdate="true"

# 2. Generated variables
tempdir=$(mktemp -d)
log="$logandmetadir/$appname.log"
metafile="$logandmetadir/$appname.meta"

# 3. Supporting Functions
function startLog() {
    mkdir -p "$logandmetadir"
    exec > >(tee -a "$log") 2>&1
}

function waitForProcess () {
    processName=$1
    echo "$(date) | Waiting for other [$processName] processes to end"
    while ps aux | grep "$processName" | grep -v grep &>/dev/null; do
        if [[ $3 == "true" ]]; then
            echo "$(date) | Terminating $processName..."
            pkill -f "$processName"
            return
        fi
        sleep 10
    done
}

function fetchLastModifiedDate() {
    if [[ ! -d "$logandmetadir" ]]; then
        mkdir -p "$logandmetadir"
    fi
    lastmodified=$(curl -sIL "$weburl" | grep -i "last-modified" | awk '{$1=""; print $0}' | awk '{ sub(/^[ \t]+/, ""); print }' | tr -d '\r')
    if [[ $1 == "update" ]]; then
        echo "$lastmodified" > "$metafile"
    fi
}

function downloadApp () {
    echo "$(date) | Starting download of [$appname]..."
    cd "$tempdir"
    curl -o "Microsoft_Remote_Help_installer.pkg" -f -s --connect-timeout 30 --retry 5 --retry-delay 60 -L -J "$weburl"
    if [[ $? == 0 ]]; then
        tempfile="Microsoft_Remote_Help_installer.pkg"
        packageType="PKG"
        echo "$(date) | Download successful."
    else
        echo "$(date) | ERROR: Download failed."
        exit 1
    fi
}

function updateCheck() {
    if [ -d "/Applications/$app" ]; then
        if [[ $autoUpdate == "true" ]]; then
            echo "$(date) | $appname already installed, exiting."
            exit 0
        fi
    fi
}

function installPKG () {
    waitForProcess "$processpath" "300" "$terminateprocess"
    echo "$(date) | Installing $appname PKG..."
    if [[ -d "/Applications/$app" ]]; then
        rm -rf "/Applications/$app"
    fi
    # PKG installations for Remote Help must target the root volume /
    installer -pkg "$tempfile" -target /
    if [ "$?" = "0" ]; then
        fetchLastModifiedDate update
        echo "$(date) | $appname installed successfully."
        exit 0
    else
        echo "$(date) | ERROR: Installation failed."
        exit 1
    fi
}

function waitForDesktop () {
  until ps aux | grep /System/Library/CoreServices/Dock.app/Contents/MacOS/Dock | grep -v grep &>/dev/null; do
    sleep 5
  done
}

# --- Main Body ---
startLog
updateCheck
waitForDesktop

downloadApp

if [[ $packageType == "PKG" ]]; then
    installPKG
fi