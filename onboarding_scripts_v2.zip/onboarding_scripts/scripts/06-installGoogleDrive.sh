#!/bin/bash
# VER 2.0.0 - Static Version (UI handled by Master)

# 1. User Defined variables
weburl="https://dl.google.com/drive-file-stream/GoogleDrive.dmg"
appname="Google Drive"
app="Google Drive.app"
logandmetadir="/Library/Logs/Microsoft/IntuneScripts/GoogleDrive"
processpath="/Applications/Google Drive.app/Contents/MacOS/Google Drive"
terminateprocess="true"
autoUpdate="true"

# 2. Generated variables
tempdir=$(mktemp -d)
log="$logandmetadir/$appname.log"
metafile="$logandmetadir/$appname.meta"

# 3. Supporting Functions
function startLog() {
    mkdir -p "$logandmetadir"
    exec > >(tee -a "$log") 2>&1
}

function waitForProcess () {
    processName=$1
    echo "$(date) | Checking if [$processName] is running..."
    while ps aux | grep "$processName" | grep -v grep &>/dev/null; do
        if [[ $3 == "true" ]]; then
            echo "$(date) | Terminating $processName..."
            pkill -f "$processName"
            return
        fi
        sleep 10
    done
}

function checkForRosetta2 () {
    echo "$(date) | Checking Rosetta status..."
    processor=$(/usr/sbin/sysctl -n machdep.cpu.brand_string)
    if [[ "$processor" != *"Intel"* ]]; then
        if [[ ! -f "/Library/Apple/System/Library/LaunchDaemons/com.apple.oahd.plist" ]]; then
            echo "$(date) | Installing Rosetta 2..."
            /usr/sbin/softwareupdate --install-rosetta --agree-to-license
        fi
    fi
}

function downloadApp () {
    echo "$(date) | Starting download of [$appname]..."
    cd "$tempdir"
    curl -f -s --connect-timeout 30 --retry 5 --retry-delay 60 -L -J -O "$weburl"
    if [ $? == 0 ]; then
            tempfile=$(ls $tempdir/* | head -n 1)
            echo "$(date) | Download complete: $tempfile"
    else
         echo "$(date) | ERROR: Download failed"
         exit 1
    fi
}

function updateCheck() {
    if [ -d "/Applications/$app" ]; then
        if [[ $autoUpdate == "true" ]]; then
            echo "$(date) | $appname already installed, exiting."
            exit 0
        fi
    fi
}

function installDMGPKG () {
    waitForProcess "$processpath" "300" "$terminateprocess"
    echo "$(date) | Mounting DMG and installing $appname..."
    volume="$tempdir/GoogleDrive"
    hdiutil attach -quiet -nobrowse -mountpoint "$volume" "$tempfile"
    
    # Install the PKG found inside the DMG
    for file in "$volume"/*.pkg; do
        echo "$(date) | Installing [$file]..."
        installer -pkg "$file" -target /
    done

    hdiutil detach -quiet "$volume"
    if [[ -d "/Applications/$app" ]]; then
        echo "$(date) | $appname installed successfully."
        exit 0
    else
        echo "$(date) | ERROR: Installation failed."
        exit 1
    fi
}

function waitForDesktop () {
  until ps aux | grep /System/Library/CoreServices/Dock.app/Contents/MacOS/Dock | grep -v grep &>/dev/null; do
    sleep 5
  done
}

# --- Main Body ---
startLog
checkForRosetta2
updateCheck
waitForDesktop

downloadApp
installDMGPKG