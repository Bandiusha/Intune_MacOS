#!/bin/bash
# VER 2.0.0 - Static Version (UI handled by Master)

# 1. Variables
weburl="https://vault.bitwarden.com/download/?app=desktop&platform=macos"
appname="Bitwarden"
app="Bitwarden.app"
logdir="/Library/Logs/Microsoft/IntuneScripts/Bitwarden"
logfile="$logdir/Bitwarden.log"
tempdir=$(mktemp -d)

# 2. Setup Logging
mkdir -p "$logdir"
exec &> >(tee -a "$logfile")

echo "--- NEW INSTALL START: $(date) ---"

function waitForDesktop () {
  until ps aux | grep /System/Library/CoreServices/Dock.app/Contents/MacOS/Dock | grep -v grep &>/dev/null; do
    sleep 5
  done
}

# --- Body ---

# Ensure user is logged in
waitForDesktop

# 3. Download
echo "$(date) | Downloading Bitwarden..."
curl -L -f -s -o "$tempdir/bitwarden.dmg" "$weburl"

# Check if download was successful
if [ $? -ne 0 ]; then
    echo "$(date) | ERROR: Download failed."
    exit 1
fi

# 4. Mount
echo "$(date) | Mounting DMG..."
hdiutil attach -quiet -nobrowse -noverify "$tempdir/bitwarden.dmg"
# Find the volume name dynamically
mountPoint=$(ls /Volumes | grep -i "Bitwarden" | head -n 1)

# 5. Install
echo "$(date) | Installing Bitwarden.app..."
if [ -d "/Volumes/$mountPoint/$app" ]; then
    echo "$(date) | Removing old app if it exists..."
    rm -rf "/Applications/$app"
    echo "$(date) | Copying to Applications..."
    cp -R "/Volumes/$mountPoint/$app" "/Applications/"
else
    echo "$(date) | ERROR: Could not find Bitwarden in DMG"
    hdiutil detach -quiet "/Volumes/$mountPoint"
    exit 1
fi

# 6. FIX THE "CAN'T BE OPENED" ERROR
echo "$(date) | Applying Gatekeeper and Permission fixes..."
# This removes the "Damaged" message caused by web downloads
xattr -rd com.apple.quarantine "/Applications/$app"
chmod -R 755 "/Applications/$app"
chown -R root:wheel "/Applications/$app"

# 7. Cleanup
echo "$(date) | Cleaning up..."
hdiutil detach -quiet "/Volumes/$mountPoint"
rm -rf "$tempdir"

echo "$(date) | SUCCESS: Bitwarden installed successfully at $(date)"
exit 0