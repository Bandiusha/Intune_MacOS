#!/bin/zsh
# VER 2.0.0 - Static Version (UI handled by Master)

# 1. User Defined variables
weburl="https://go.microsoft.com/fwlink/?linkid=2097502"
appname="Microsoft Defender"
app="Microsoft Defender.app"
logandmetadir="/Library/Application Support/Microsoft/IntuneScripts/installDefender"
processpath="/Applications/Microsoft Defender.app/Contents/MacOS/Microsoft Defender"
terminateprocess="true"
autoUpdate="true"
secondsToWaitForOtherApps=3600

waitForTheseApps=(  "/Applications/Microsoft Outlook.app"
                    "/Applications/Microsoft Word.app"
                    "/Applications/Microsoft Excel.app"
                    "/Applications/Microsoft PowerPoint.app"
                    "/Applications/Microsoft OneNote.app"
                    "/Applications/Microsoft Teams.app"
                    "/Applications/Company Portal.app")

# 2. Generated variables
tempdir=$(mktemp -d)
log="$logandmetadir/$appname.log"
metafile="$logandmetadir/$appname.meta"

# 3. Supporting Functions
function startLog() {
    mkdir -p "$logandmetadir"
    exec > >(tee -a "$log") 2>&1
}

function installAria2c () {
    ARIA2="/usr/local/aria2/bin/aria2c"
    if [[ ! -f $ARIA2 ]]; then
        echo "$(date) | Installing Aria2c..."
        aria2Url="https://github.com/aria2/aria2/releases/download/release-1.35.0/aria2-1.35.0-osx-darwin.dmg"
        output="$tempdir/aria2.dmg"
        curl -f -s -L -o "$output" "$aria2Url"
        mountpoint="$tempdir/aria2"
        hdiutil attach -quiet -nobrowse -mountpoint "$mountpoint" "$output"
        sudo installer -pkg "$mountpoint/aria2.pkg" -target /
        hdiutil detach -quiet "$mountpoint"
    fi
}

waitForOtherApps() {
    echo "$(date) | Checking for dependent applications..."
    START=$(date +%s)
    ready=0
    while [[ $ready -ne 1 ]]; do
        if [[ $(($(date +%s) - $START)) -ge $secondsToWaitForOtherApps ]]; then
            echo "$(date) | Timeout waiting for dependencies: Continuing anyway."
            break
        fi

        missingappcount=0
        for i in "${waitForTheseApps[@]}"; do
            [[ ! -d "$i" ]] && let missingappcount=$missingappcount+1
        done

        if [[ $missingappcount -eq 0 ]]; then
            ready=1
            echo "$(date) | All dependencies met."
        else
            echo "$(date) | Still waiting for $missingappcount apps to install..."
            sleep 15
        fi
    done
}

checkForRosetta2 () {
    echo "$(date) | Checking Rosetta 2 status..."
    processor=$(/usr/sbin/sysctl -n machdep.cpu.brand_string | grep -o "Intel")
    if [[ -z "$processor" ]]; then
        if ! /usr/bin/pgrep oahd >/dev/null 2>&1; then
            echo "$(date) | Installing Rosetta 2..."
            /usr/sbin/softwareupdate --install-rosetta --agree-to-license
        fi
    fi
}

downloadApp () {
    echo "$(date) | Downloading Microsoft Defender..."
    /usr/local/aria2/bin/aria2c -q -x16 -s16 -d "$tempdir" "$weburl" --download-result=hide --summary-interval=0
    tempfile=$(ls $tempdir/*.pkg | head -n 1)
}

updateCheck() {
    if [ -d "/Applications/$app" ]; then
        echo "$(date) | $appname is already installed."
        exit 0
    fi
}

installPKG () {
    echo "$(date) | Installing Defender PKG..."
    installer -pkg "$tempfile" -target /
    if [[ $? -eq 0 ]]; then
        echo "$(date) | Defender installed successfully."
        exit 0
    else
        echo "$(date) | Defender installation failed."
        exit 1
    fi
}

waitForDesktop () {
  until ps aux | grep /System/Library/CoreServices/Dock.app/Contents/MacOS/Dock | grep -v grep &>/dev/null; do
    sleep 5
  done
}

# --- Main Body ---
startLog
installAria2c
checkForRosetta2
updateCheck
waitForDesktop

# Wait for Office and Company Portal to finish first
waitForOtherApps

downloadApp
installPKG