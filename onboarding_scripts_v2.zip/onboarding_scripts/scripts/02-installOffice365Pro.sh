#!/bin/bash
# VER 2.0.0 - Static Version (UI handled by Master)

# 1. User Defined variables
weburl="https://go.microsoft.com/fwlink/?linkid=2009112"
appname="Microsoft Office"
logandmetadir="/Library/Application Support/Microsoft/IntuneScripts/installOffice"
terminateprocess="true"
autoUpdate="true"

# 2. Generated variables
tempdir=$(mktemp -d)
tempfile="$appname.pkg"
log="$logandmetadir/$appname.log"
metafile="$logandmetadir/$appname.meta"

# 3. Supporting Functions
function startLog() {
    mkdir -p "$logandmetadir"
    exec &> >(tee -a "$log")
}

function installAria2c () {
    ARIA2="/usr/local/aria2/bin/aria2c"
    aria2Url="https://github.com/aria2/aria2/releases/download/release-1.35.0/aria2-1.35.0-osx-darwin.dmg"
    if [[ -f $ARIA2 ]]; then
        echo "$(date) | Aria2 already installed"
    else
        echo "$(date) | Installing Aria2..."
        filename=$(basename "$aria2Url")
        output="$tempdir/$filename"
        curl -f -s -L -o "$output" "$aria2Url"
        mountpoint="$tempdir/aria2"
        hdiutil attach -quiet -nobrowse -mountpoint "$mountpoint" "$output"
        sudo installer -pkg "$mountpoint/aria2.pkg" -target /
        hdiutil detach -quiet "$mountpoint"
    fi
}

waitForProcess () {
    processName=$1
    while ps aux | grep "$processName" | grep -v grep &>/dev/null; do
        if [[ $3 == "true" ]]; then
            pkill -f "$processName"
            return
        fi
        sleep 10
    done
}

fetchLastModifiedDate() {
    if [[ ! -d "$logandmetadir" ]]; then mkdir -p "$logandmetadir"; fi
    lastmodified=$(curl -sIL "$weburl" | grep -i "last-modified" | awk '{$1=""; print $0}' | awk '{ sub(/^[ \t]+/, ""); print }' | tr -d '\r')
    if [[ $1 == "update" ]]; then echo "$lastmodified" > "$metafile"; fi
}

downloadApp () {
    echo "$(date) | Starting download of Office 365..."
    /usr/local/aria2/bin/aria2c -q -x16 -s16 -d "$tempdir" -o "$tempfile" "$weburl" --download-result=hide --summary-interval=0
    if [ $? -ne 0 ]; then
        echo "$(date) | Download Failed"
        exit 1
    fi
}

updateCheck() {
    OfficeApps=( "/Applications/Microsoft Excel.app" "/Applications/Microsoft OneNote.app" "/Applications/Microsoft Outlook.app" "/Applications/Microsoft PowerPoint.app" "/Applications/Microsoft Teams.app" "/Applications/Microsoft Word.app")
    for i in "${OfficeApps[@]}"; do
        if [[ ! -e "$i" ]]; then return; fi
    done
    if [[ $autoUpdate == "true" ]]; then
        echo "$(date) | Office 365 apps already present."
        exit 0
    fi
}

installPKG () {
    echo "$(date) | Installing Office 365 PKG..."
    installer -pkg "$tempdir/$tempfile" -target /
    if [ "$?" = "0" ]; then
        fetchLastModifiedDate update
        echo "$(date) | Office 365 Installed Successfully"
        rm -rf "$tempdir"
        exit 0
    else
        echo "$(date) | Installation Failed"
        exit 1
    fi
}

waitForDesktop () {
  until ps aux | grep /System/Library/CoreServices/Dock.app/Contents/MacOS/Dock | grep -v grep &>/dev/null; do
    sleep 5
  done
}

# --- Body ---
startLog
installAria2c
updateCheck
waitForDesktop
downloadApp
installPKG