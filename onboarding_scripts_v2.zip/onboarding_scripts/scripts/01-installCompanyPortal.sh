#!/bin/bash
# VER 2.0.0 - Static Version (UI handled by Master)

# 1. User Defined variables
mauurl="https://go.microsoft.com/fwlink/?linkid=830196"
weburl="https://go.microsoft.com/fwlink/?linkid=853070"
appname="Company Portal"
app="Company Portal.app"
filedownloaded="CompanyPortal-Installer.pkg"
logandmetadir="/Library/Logs/Microsoft/IntuneScripts/installCompanyPortal"
processpath="/Applications/Company Portal.app/Contents/MacOS/Company Portal"
terminateprocess="true"
autoUpdate="true"

# 2. Generated variables
tempdir=$(mktemp -d)
log="$logandmetadir/$appname.log"
metafile="$logandmetadir/$appname.meta"

# 3. Supporting Functions
function startLog() { 
    mkdir -p "$logandmetadir"
    exec &> >(tee -a "$log") 
}

waitForProcess () {
    processName=$1
    fixedDelay=$2
    terminate=$3
    while ps aux | grep "$processName" | grep -v grep &>/dev/null; do
        if [[ $terminate == "true" ]]; then
            pkill -f "$processName"
            return
        fi
        sleep ${fixedDelay:-10}
    done
}

waitForDesktop () { 
    until ps aux | grep /System/Library/CoreServices/Dock.app/Contents/MacOS/Dock | grep -v grep &>/dev/null; do 
        sleep 5 
    done 
}

# 4. Execution Logic
function downloadApp () {
    echo "$(date) | Downloading $appname..."
    cd "$tempdir"
    curl -o "$tempdir/$filedownloaded" -f -s -L -J "$weburl"
    if [ $? -eq 0 ]; then
        tempfile=$(ls $tempdir/* | head -n 1)
    else
        echo "$(date) | Download Failed"
        exit 1
    fi
}

function installPKG () {
    echo "$(date) | Installing $appname..."
    installer -pkg "$tempfile" -target /
    if [ "$?" = "0" ]; then
        echo "$(date) | Successfully Installed"
        rm -rf "$tempdir"
        exit 0
    else
        echo "$(date) | Installation Failed"
        exit 1
    fi
}

# --- Main Body ---
startLog
waitForDesktop

# Check if already installed
if [ -d "/Applications/$app" ] && [[ $autoUpdate == "true" ]]; then
    echo "$(date) | $appname already installed."
    exit 0
fi

downloadApp
installPKG