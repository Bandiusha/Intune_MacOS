#!/bin/bash
# VER 2.0.0 - Static Version (UI handled by Master)

# 1. User Defined variables
currentVersion=$(curl -LSs "https://armmf.adobe.com/arm-manifests/mac/AcrobatDC/acrobat/current_version.txt" | sed 's/\.//g')
weburl="https://ardownload2.adobe.com/pub/adobe/reader/mac/AcrobatDC/${currentVersion}/AcroRdrDC_${currentVersion}_MUI.dmg"
appname="Adobe Acrobat Reader DC"
app="Adobe Acrobat Reader DC.app"
logandmetadir="/Library/Logs/Microsoft/IntuneScripts/Adobe Acrobat Reader DC"
processpath="/Applications/Adobe Acrobat Reader DC.app/Contents/MacOS/AdobeReader"
terminateprocess="false"
autoUpdate="true"

# 2. Generated variables
tempdir=$(mktemp -d)
log="$logandmetadir/$appname.log"
metafile="$logandmetadir/$appname.meta"

# 3. Supporting Functions
function startLog() {
    mkdir -p "$logandmetadir"
    exec &> >(tee -a "$log")
}

function waitForProcess () {
    processName=$1
    echo "$(date) | Waiting for other [$processName] processes to end"
    while ps aux | grep "$processName" | grep -v grep &>/dev/null; do
        if [[ $3 == "true" ]]; then
            pkill -f "$processName"
            return
        fi
        sleep 10
    done
}

function checkForRosetta2 () {
    echo "$(date) | Checking Rosetta 2 status..."
    processor=$(/usr/sbin/sysctl -n machdep.cpu.brand_string | grep -o "Intel")
    if [[ -z "$processor" ]]; then
        if ! /usr/bin/pgrep oahd >/dev/null 2>&1; then
            echo "$(date) | Installing Rosetta 2..."
            /usr/sbin/softwareupdate --install-rosetta --agree-to-license
        fi
    fi
}

function fetchLastModifiedDate() {
    if [[ ! -d "$logandmetadir" ]]; then
        mkdir -p "$logandmetadir"
    fi
    lastmodified=$(curl -sIL "$weburl" | grep -i "last-modified" | awk '{$1=""; print $0}' | awk '{ sub(/^[ \t]+/, ""); print }' | tr -d '\r')
    if [[ $1 == "update" ]]; then
        echo "$lastmodified" > "$metafile"
    fi
}

function downloadApp () {
    echo "$(date) | Starting download of $appname"
    cd "$tempdir"
    curl -f -s --connect-timeout 30 --retry 5 --retry-delay 60 --compressed -L -J -O "$weburl"
    if [ $? == 0 ]; then
            tempfile=$(ls $tempdir/* | head -n 1)
            echo "$(date) | Downloaded to [$tempfile]"
    else
         echo "$(date) | ERROR: Failure to download [$weburl]"
         exit 1
    fi
}

function updateCheck() {
    if [ -d "/Applications/$app" ]; then
        if [[ $autoUpdate == "true" ]]; then
            echo "$(date) | $appname already installed, exiting."
            exit 0
        fi
    fi
}

function installDMGPKG () {
    waitForProcess "$processpath" "300" "$terminateprocess"
    echo "$(date) | Installing $appname..."
    volume="$tempdir/Acrobat"
    hdiutil attach -quiet -nobrowse -mountpoint "$volume" "$tempfile"
    
    # Acrobat usually contains one .pkg file in the DMG
    for file in "$volume"/*.pkg; do
        echo "$(date) | Installing [$file]"
        installer -pkg "$file" -target /
    done
    
    hdiutil detach -quiet "$volume"
    if [[ -d "/Applications/$app" ]]; then
        echo "$(date) | $appname installed successfully."
        fetchLastModifiedDate update
        exit 0
    else
        echo "$(date) | ERROR: Installation failed."
        exit 1
    fi
}

function waitForDesktop () {
  until ps aux | grep /System/Library/CoreServices/Dock.app/Contents/MacOS/Dock | grep -v grep &>/dev/null; do
    sleep 5
  done
}

# --- Main Body ---
startLog
checkForRosetta2
updateCheck
waitForDesktop

downloadApp
installDMGPKG