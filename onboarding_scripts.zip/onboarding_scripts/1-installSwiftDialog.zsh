#!/bin/zsh
# Static UI Launcher
weburl="https://github.com/bartreardon/swiftDialog/releases/download/v2.2/dialog-2.2.0-4535.pkg"
json_path="/Library/Application Support/Microsoft/IntuneScripts/Swift Dialog/swiftdialog.json"

# 1. Install Swift Dialog
tempdir=$(mktemp -d)
curl -f -s -L -o "$tempdir/dialog.pkg" "$weburl"
installer -pkg "$tempdir/dialog.pkg" -target /

# 2. Setup Communication Log (CRITICAL)
# We create the file and give it 666 permissions so any script can write to it
touch /var/tmp/dialog.log
chmod 666 /var/tmp/dialog.log

# 3. Wait for user session
until ps aux | grep /System/Library/CoreServices/Dock.app/Contents/MacOS/Dock | grep -v grep &>/dev/null; do
    sleep 5
done

CURRENT_USER=$(stat -f "%Su" /dev/console)
USER_ID=$(id -u "$CURRENT_USER")

# 4. Launch UI with Command File Flag
launchctl asuser "$USER_ID" /usr/local/bin/dialog \
    --jsonfile "$json_path" \
    --progress 100 \
    --progresstext "Starting installations..." \
    --button1disabled \
    --commandfile "/var/tmp/dialog.log" \
    --width 1024 --height 500 &

exit 0