#!/bin/zsh
# SPEED-OPTIMIZED UI Launcher

# 1. Initialize the log file with full permissions
echo "" > /var/tmp/dialog.log
chmod 666 /var/tmp/dialog.log

# 2. Skip download if already installed
if [[ ! -f "/usr/local/bin/dialog" ]]; then
    weburl="https://github.com/bartreardon/swiftDialog/releases/download/v2.2/dialog-2.2.0-4535.pkg"
    curl -f -s -L -o "/tmp/dialog.pkg" "$weburl"
    installer -pkg "/tmp/dialog.pkg" -target /
fi

# 3. Faster Dock Check
until pgrep -x "Dock" &>/dev/null; do
    sleep 1
done

sleep 2 

CURRENT_USER=$(stat -f "%Su" /dev/console)
USER_ID=$(id -u "$CURRENT_USER")

# 4. Launch with full path, explicit dimensions, and commandfile
launchctl asuser "$USER_ID" /usr/local/bin/dialog \
    --jsonfile "/Library/Application Support/Microsoft/IntuneScripts/Swift Dialog/swiftdialog.json" \
    --progress 100 \
    --button1disabled \
    --width 1280 \
    --height 720 \
    --commandfile "/var/tmp/dialog.log" &